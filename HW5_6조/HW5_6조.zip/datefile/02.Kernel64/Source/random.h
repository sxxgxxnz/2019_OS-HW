#ifndef __RANDOM_H__
#define __RANDOM_H__ 

#include "Types.h"
#include "AssemblyUtility.h"

QWORD random_generator();

#endif